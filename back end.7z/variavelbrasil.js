var n = 200 // atribuindo à variável n o número 200
var t = 'Oi Brasil, cheguei, cheguei Brasil'
x=n*t
console.log = (x)