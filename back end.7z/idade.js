let idade = 28;
let result = "";

if (idade >= 60){result="PODE APOSENTAR"}
else
if (idade >= 55){result="JÁ PODE PEDIR APOSENTADORIA"}
else
 {result="AINDA NÃO TEM IDADE PARA APOSENTAR"}

 console.log("O seu cliente: " + result)