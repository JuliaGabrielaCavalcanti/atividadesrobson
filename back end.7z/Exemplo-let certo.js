var exibeMensagem = 1
    if (exibeMensagem = 1) {
        var forabloco = "Java";
        var dentroBloco = "Alura";
        var dentroblocotbm = "Polo"
        console.log(dentroBloco); //Alura
        console.log(forabloco);
        console.log(dentroblocotbm);
    }

    console.log("Apresentar FORA do bloco");
    console.log(forabloco);//Java
    console.log(dentroBloco);
    console.log(dentroblocotbm);