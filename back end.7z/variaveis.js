var n1 = 5 
var n2 = 8.5 
var n3 = 15 
 
var s1 = "JavaScript" 
var s2 = "Polo Arapongas"
var s3 = "3 Ano 2025"

console.log(n1)
console.log(n2)
console.log(n3)
console.log(s1)
console.log(s2)
console.log(s3)