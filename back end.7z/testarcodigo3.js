            N = 700
            if (N >= 200) {
                // true
                console.log('O valor de N é MAIOR que 200!')
            } else{
            // Condição composta
            if (N >= 100) {
                //true
                console.log('O valor de N é MAIOR que 100!')
            } else {
                //false
                console.log('O valor de N é MENOR que 100!')
            }
        }
